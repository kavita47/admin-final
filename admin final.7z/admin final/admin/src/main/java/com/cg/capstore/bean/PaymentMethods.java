package com.cg.capstore.bean;

public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
